import json
import os
from sts.sts import Sts

#os.environ
# 密钥的权限列表。简单上传和分片需要以下的权限，其他权限列表请看 https://cloud.tencent.com/document/product/436/31923

def to_json(r):
    return json.dumps(r, indent=4)

def main():
    r={"ok":False,"data":{}}
    config = {
        'duration_seconds': 1800,
        'secret_id': 'AKIDlQ2ZnrCd2iI1bx5F9i9dtSn374tsacZc',
        'secret_key': 'aO7QfZBKGNROEtcI7GONLD2H1a1Ll17B',
        'bucket': 'ttt-1252957949',
        'region': 'ap-hongkong',
        'allow_prefix': '*',
        'allow_actions': [
            'name/cos:PutObject',
            'name/cos:PostObject',
            'name/cos:InitiateMultipartUpload',
            'name/cos:ListMultipartUploads',
            'name/cos:ListParts',
            'name/cos:UploadPart',
            'name/cos:CompleteMultipartUpload'
        ],

    }
    try:
        sts = Sts(config)
        response = sts.get_credential()
        r['data']=response
    except Exception as e:
        print(e)
    finally:
        return r

