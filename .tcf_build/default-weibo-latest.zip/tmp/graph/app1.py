from graphene import ObjectType, String, Schema
import datetime
from graphene.types import Scalar
from graphql.language import ast








'''
type Query {
  hello(name: String = "stranger"): String
  goodbye: String
}
'''

class Query(ObjectType):
    hello = String(name=String(default_value="stranger")) # { hello(name: "GraphQL") }
    goodbye = String()
    def resolve_hello(root, info, name):
        return f'Hello {name}!'
    def resolve_goodbye(root, info):
        return 'See ya!'

'''
{ hello }
{ hello(name: "GraphQL") }

'''


class Person(graphene.ObjectType):
    last_name = graphene.String()
    other_name = graphene.String(name='_other_Name')
'''
{
    lastName
    _other_Name
}

'''

class Person(graphene.ObjectType):
    name = graphene.String()

# Is equivalent to:
class Person(graphene.ObjectType):
    name = graphene.Field(graphene.String)

class Person(graphene.ObjectType):
    name= graphene.Field(graphene.String, to=graphene.String())
    # Is equivalent to:
    name= graphene.Field(graphene.String, to=graphene.Argument(graphene.String))


























class DateTime(Scalar):
    '''DateTime Scalar Description'''
    @staticmethod
    def serialize(dt):
        return dt.isoformat()
    @staticmethod
    def parse_literal(node):
        if isinstance(node, ast.StringValue):
            return datetime.datetime.strptime(
                node.value, "%Y-%m-%dT%H:%M:%S.%f")
    @staticmethod
    def parse_value(value):
        return datetime.datetime.strptime(value, "%Y-%m-%dT%H:%M:%S.%f")









def app(query_string='{ hello }'):
    schema = Schema(query=Query)
    result = schema.execute(query_string)
    return result

def test():
    query_string = '{ hello(name: "GraphQL") }'
    result=app(query_string)
    print(result.data)





def test1():
    my_schema = Schema(
        query=MyRootQuery,
        mutation=MyRootMutation,
        subscription=MyRootSubscription,
       #auto_camelcase=False,
       #types=[SomeExtraObjectType, ]
    )
    query_string = 'query whoIsMyBestFriend { myBestFriend { lastName } }'
    r=my_schema.execute(query_string)
    print(r)


def test3():

