https://github.com/ReactiveX/RxPY

```python



import asyncio
import concurrent.futures
import time

import rx
from rx import operators as ops


import requests

def get(u,p={}):
    headers={
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:70.0) Gecko/20100101 Firefox/70.0",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Pragma": "no-cache",
        "Cache-Control": "no-cache"
    }
    return requests.get(u,params=p,headers=headers).text

def search_baidu(term=""):
    url="https://www.baidu.com/s"
    params = {
        'wd': term, 
        'rsv_spt': '1', 
        'rsv_iqid': '0xf5345b9c000f2ca8', 
        'issp': '1', 
        'f': '8', 
        'rsv_bp': '1', 
        'rsv_idx': '2', 
        'ie': 'utf-8', 
        'rqlang': '', 
        'tn': 'baiduhome_pg', 
        'ch': '', 
        'rsv_enter': '0', 
        'rsv_dl': 'ib', 
        'inputT': '1062'
    }
    return get(url,params)


def get_baidu():
    u="http://www.baidu.com"
    stream = rx.just(get(u))
    return stream 

def sleep(tm):
    time.sleep(tm)
    return tm    

    
#parallel
def timer():
    seconds = [5, 1, 2, 4, 3]
    with concurrent.futures.ProcessPoolExecutor(5) as executor:
        rx.from_(seconds).pipe(
            ops.flat_map(lambda s: executor.submit(sleep, s))
        ).subscribe(print)


def test1():
    source = rx.of("Alpha", "Beta", "Gamma", "Delta", "Epsilon")
    composed = source.pipe(
        ops.map(lambda s: len(s)),
        ops.filter(lambda i: i >= 5)
    )
    composed.subscribe(lambda value: print("Received {0}".format(value)))

def test_async():
    stream = rx.just("Hello, world!")
    async def hello_world():
        n = await stream
        print(n)
    loop = asyncio.get_event_loop()
    loop.run_until_complete(hello_world())
    loop.close()

#https://github.com/ReactiveX/RxPY/blob/master/examples/autocomplete/autocomplete.py
import os
from tornado.websocket import WebSocketHandler
from tornado.web import RequestHandler, StaticFileHandler, Application, url
from tornado.httpclient import AsyncHTTPClient
from tornado.httputil import url_concat
from tornado.escape import json_decode
from tornado import ioloop

from rx.subject import Subject
from rx.scheduler.eventloop import IOLoopScheduler

def test2(obj={"term":"ccc"}):
    scheduler = IOLoopScheduler(ioloop.IOLoop.current())
    stream = Subject()
    stream.on_next(obj)
    stream
    .pipe(
            ops.map(lambda x: x["term"]),
            ops.filter(lambda text: len(text) > 2),  
            ops.debounce(0.750),                    
            ops.distinct_until_changed(),          
            ops.flat_map_latest(search_baidu)
        )
    .subscribe(print, print, scheduler=scheduler)     



rx.Any
rx.Callable
rx.Iterable
rx.Mapping
rx.Observable
rx.Optional
rx.Union
rx.alias
rx.amb
rx.case
rx.catch
rx.catch_with_iterable
rx.cold
rx.combine_latest
rx.concat
rx.concat_with_iterable
rx.core
rx.create
rx.defer
rx.disposable
rx.empty
rx.for_in
rx.from_
rx.from_callable
rx.from_callback
rx.from_future
rx.from_iterable
rx.from_list
rx.from_marbles
rx.generate
rx.generate_with_relative_time
rx.hot
rx.if_then
rx.internal
rx.interval
rx.just
rx.merge
rx.never
rx.of(1,2,3).subscribe(print)
rx.on_error_resume_next
rx.operators
rx.pipe
rx.range
rx.repeat_value
rx.return_value
rx.scheduler
rx.start
rx.start_async
rx.subject
rx.throw
rx.timer
rx.to_async
rx.typing
rx.using
rx.with_latest_from
rx.zip


from rx import operators as ops

ops.Accumulator
ops.Any
ops.Callable
ops.Comparer
ops.ConnectableObservable
ops.Future
ops.GroupedObservable
ops.Iterable
ops.List
ops.Mapper
ops.MapperIndexed
ops.NotSet
ops.Observable
ops.Optional
ops.Predicate
ops.PredicateIndexed
ops.Subject
ops.Union
ops.all
ops.amb
ops.as_observable
ops.average
ops.buffer
ops.buffer_toggle
ops.buffer_when
ops.buffer_with_count
ops.buffer_with_time
ops.buffer_with_time_or_count
ops.cast
ops.catch
ops.combine_latest
ops.concat
ops.contains
ops.count
ops.datetime
ops.debounce
ops.default_if_empty
ops.delay
ops.delay_subscription
ops.delay_with_mapper
ops.dematerialize
ops.distinct
ops.distinct_until_changed
ops.do
ops.do_action
ops.do_while
ops.element_at
ops.element_at_or_default
ops.exclusive
ops.expand
ops.filter
ops.filter_indexed
ops.finally_action
ops.find
ops.find_index
ops.first
ops.first_or_default
ops.flat_map
ops.flat_map_indexed
ops.flat_map_latest
ops.group_by
ops.group_by_until
ops.group_join
ops.ignore_elements
ops.is_empty
ops.join
ops.last
ops.last_or_default
ops.map
ops.map_indexed
ops.materialize
ops.max
ops.max_by
ops.merge
ops.merge_all
ops.min
ops.min_by
ops.multicast
ops.observe_on
ops.on_error_resume_next
ops.overload
ops.pairwise
ops.partition
ops.partition_indexed
ops.pipe
ops.pluck
ops.pluck_attr
ops.publish
ops.publish_value
ops.reduce
ops.ref_count
ops.repeat
ops.replay
ops.retry
ops.sample
ops.scan
ops.sequence_equal
ops.share
ops.single
ops.single_or_default
ops.single_or_default_async
ops.skip
ops.skip_last
ops.skip_last_with_time
ops.skip_until
ops.skip_until_with_time
ops.skip_while
ops.skip_while_indexed
ops.skip_with_time
ops.slice
ops.some
ops.starmap
ops.starmap_indexed
ops.start_with
ops.subscribe_on
ops.sum
ops.switch_latest
ops.take
ops.take_last
ops.take_last_buffer
ops.take_last_with_time
ops.take_until
ops.take_until_with_time
ops.take_while
ops.take_while_indexed
ops.take_with_time
ops.throttle_first
ops.throttle_with_mapper
ops.throttle_with_timeout
ops.time_interval
ops.timedelta
ops.timeout
ops.timeout_with_mapper
ops.timestamp
ops.to_dict
ops.to_future
ops.to_iterable
ops.to_list
ops.to_marbles
ops.to_set
ops.typing
ops.while_do
ops.window
ops.window_toggle
ops.window_when
ops.window_with_count
ops.window_with_time
ops.window_with_time_or_count
ops.with_latest_from
ops.zip
ops.zip_with_iterable
ops.zip_with_list


```
