```python

event= {
    "headerParameters": {},
    "headers": {
      "accept": "*/*",
      "endpoint-timeout": "15",
      "host": "service-75ph8ybo-1252957949.ap-hongkong.apigateway.myqcloud.com",
      "user-agent": "curl/7.61.1",
      "x-anonymous-consumer": "true",
      "x-qualifier": "$LATEST"
    },
    "httpMethod": "GET",
    "path": "/weibo/",
    "pathParameters": {},
    "queryString": {},
    "queryStringParameters": {},
    "requestContext": {
      "httpMethod": "ANY",
      "identity": {},
      "path": "/weibo",
      "serviceId": "service-75ph8ybo",
      "sourceIp": "58.60.1.28",
      "stage": "release"
    }
  }


```
