 curl 'https://www.infoq.com/vendorcontent/loadVcrs.action' -H 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8' --data 'communityIds=&topicIds='
