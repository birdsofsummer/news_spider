print(__path__)
print(__file__)
print(__name__)
